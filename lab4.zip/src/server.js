const express = require('express');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;
const logFilePath = process.env.LOG_FILE_PATH || './logs';
const logFileName = process.env.LOG_FILE_NAME || 'connections';
const logFileFormat = process.env.LOG_FILE_FORMAT || 'txt'; 

if (!fs.existsSync(logFilePath)) {
    fs.mkdirSync(logFilePath, { recursive: true });
}

const logFileFullPath = path.join(logFilePath, `${logFileName}.${logFileFormat}`);

app.use((req, res, next) => {
    const logEntry = {
        timestamp: new Date().toISOString(),
        method: req.method,
        url: req.url,
        headers: req.headers,
        ip: req.ip
    };

    let logMessage;
    if (logFileFormat === 'json') {
        logMessage = JSON.stringify(logEntry) + '\n';
    } else {
        logMessage = `Time: ${logEntry.timestamp}\nMethod: ${logEntry.method}\nURL: ${logEntry.url}\nHeaders: ${JSON.stringify(logEntry.headers)}\nIP: ${logEntry.ip}\n\n`;
    }

    fs.appendFile(logFileFullPath, logMessage, (err) => {
        if (err) {
            console.error('Error writing to log file', err);
        }
    });

    console.log(logMessage);

    next();
});

app.use(express.static(path.join(__dirname, 'dist'))); 

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
