import "@babel/polyfill";
import './index.html';
import './css/style.css';
import './css/responsive.css';
import './css/bootstrap.css';
import {div, sum} from './modules/calc'

const mult = (a, b) => a * b;

console.log("Hello world!");
console.log(mult(2, 9));
console.log(mult(2, 4));
console.log('-------------');
console.log(div(8, 2));
console.log(sum(8, 2));