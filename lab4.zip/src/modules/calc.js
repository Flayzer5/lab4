export const mult = (a, b) => a * b;
export const sum = (a, b) => a + b;
export const div = async(a, b) => a / b;